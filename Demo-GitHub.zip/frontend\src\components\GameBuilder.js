import React, { useState, useEffect } from 'react';
import '../styles/GameBuilder.css';

function GameBuilder({ onProjectCreated }) {
  const [gameTypes, setGameTypes] = useState([]);
  const [frameworks, setFrameworks] = useState([]);
  const [selectedType, setSelectedType] = useState('puzzle');
  const [selectedFramework, setSelectedFramework] = useState('phaser');
  const [gameName, setGameName] = useState('');
  const [description, setDescription] = useState('');
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(false);

  const API_BASE = 'http://localhost:5000/api';

  useEffect(() => {
    fetchTemplates();
    fetchGames();
  }, []);

  const fetchTemplates = async () => {
    try {
      const response = await fetch(`${API_BASE}/templates`);
      const data = await response.json();
      if (data.success) {
        setGameTypes(data.game_types);
        setFrameworks(data.frameworks);
      }
    } catch (error) {
      console.error('Error fetching templates:', error);
    }
  };

  const fetchGames = async () => {
    try {
      const response = await fetch(`${API_BASE}/games`);
      const data = await response.json();
      if (data.success) {
        setGames(data.games);
      }
    } catch (error) {
      console.error('Error fetching games:', error);
    }
  };

  const createGame = async (e) => {
    e.preventDefault();
    if (!gameName.trim()) {
      alert('Please enter a game name');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/games/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: gameName,
          description: description,
          game_type: selectedType,
          framework: selectedFramework
        })
      });

      const data = await response.json();
      if (data.success) {
        alert('Game created successfully!');
        setGameName('');
        setDescription('');
        setSelectedType('puzzle');
        setSelectedFramework('phaser');
        fetchGames();
        onProjectCreated();
      } else {
        alert('Error: ' + data.error);
      }
    } catch (error) {
      alert('Error creating game: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="game-builder">
      <h2>🎮 Game Builder</h2>

      <div className="builder-section">
        <h3>Create New Game</h3>

        <form onSubmit={createGame} className="builder-form">
          <div className="form-group">
            <label>Game Name</label>
            <input
              type="text"
              value={gameName}
              onChange={(e) => setGameName(e.target.value)}
              placeholder="My Amazing Game"
              required
            />
          </div>

          <div className="form-group">
            <label>Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your game..."
              rows="3"
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Game Type</label>
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value)}
              >
                {Object.entries(gameTypes).map(([key, type]) => (
                  <option key={key} value={key}>
                    {type.name}
                  </option>
                ))}
              </select>
              <p className="help-text">
                {gameTypes[selectedType]?.description}
              </p>
            </div>

            <div className="form-group">
              <label>Framework</label>
              <select
                value={selectedFramework}
                onChange={(e) => setSelectedFramework(e.target.value)}
              >
                {Object.entries(frameworks).map(([key, framework]) => (
                  <option key={key} value={key}>
                    {framework.name}
                  </option>
                ))}
              </select>
              <p className="help-text">
                {frameworks[selectedFramework]?.description}
              </p>
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-primary"
          >
            {loading ? 'Creating...' : '✨ Create Game'}
          </button>
        </form>
      </div>

      <div className="games-section">
        <h3>Your Games ({games.length})</h3>
        {games.length === 0 ? (
          <p className="no-items">No games created yet. Create one above!</p>
        ) : (
          <div className="games-list">
            {games.map((game) => (
              <div key={game.id} className="game-card">
                <div className="game-info">
                  <h4>{game.name}</h4>
                  <p>{game.description}</p>
                  <div className="game-meta">
                    <span className="badge game-type">{game.game_type}</span>
                    <span className="badge framework">{game.framework}</span>
                    <span className="date">
                      Created: {new Date(game.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <div className="game-actions">
                  <button className="btn-small">▶️ Play</button>
                  <button className="btn-small">✏️ Edit</button>
                  <button className="btn-small">📦 Export</button>
                  <button className="btn-small danger">🗑️ Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default GameBuilder;
