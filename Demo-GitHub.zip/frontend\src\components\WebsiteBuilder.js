import React, { useState, useEffect } from 'react';
import '../styles/WebsiteBuilder.css';

function WebsiteBuilder({ onProjectCreated }) {
  const [templates, setTemplates] = useState([]);
  const [selectedTemplate, setSelectedTemplate] = useState('basic');
  const [websiteName, setWebsiteName] = useState('');
  const [description, setDescription] = useState('');
  const [websites, setWebsites] = useState([]);
  const [loading, setLoading] = useState(false);

  const API_BASE = 'http://localhost:5000/api';

  useEffect(() => {
    fetchTemplates();
    fetchWebsites();
  }, []);

  const fetchTemplates = async () => {
    try {
      const response = await fetch(`${API_BASE}/templates`);
      const data = await response.json();
      if (data.success) {
        setTemplates(data.website_templates);
      }
    } catch (error) {
      console.error('Error fetching templates:', error);
    }
  };

  const fetchWebsites = async () => {
    try {
      const response = await fetch(`${API_BASE}/websites`);
      const data = await response.json();
      if (data.success) {
        setWebsites(data.websites);
      }
    } catch (error) {
      console.error('Error fetching websites:', error);
    }
  };

  const createWebsite = async (e) => {
    e.preventDefault();
    if (!websiteName.trim()) {
      alert('Please enter a website name');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(`${API_BASE}/websites/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: websiteName,
          description: description,
          template: selectedTemplate
        })
      });

      const data = await response.json();
      if (data.success) {
        alert('Website created successfully!');
        setWebsiteName('');
        setDescription('');
        setSelectedTemplate('basic');
        fetchWebsites();
        onProjectCreated();
      } else {
        alert('Error: ' + data.error);
      }
    } catch (error) {
      alert('Error creating website: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="website-builder">
      <h2>🌐 Website Builder</h2>

      <div className="builder-section">
        <h3>Create New Website</h3>

        <form onSubmit={createWebsite} className="builder-form">
          <div className="form-group">
            <label>Website Name</label>
            <input
              type="text"
              value={websiteName}
              onChange={(e) => setWebsiteName(e.target.value)}
              placeholder="My Awesome Website"
              required
            />
          </div>

          <div className="form-group">
            <label>Description</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe your website..."
              rows="3"
            />
          </div>

          <div className="form-group">
            <label>Template</label>
            <div className="template-grid">
              {Object.entries(templates).map(([key, template]) => (
                <div
                  key={key}
                  className={`template-card ${selectedTemplate === key ? 'selected' : ''}`}
                  onClick={() => setSelectedTemplate(key)}
                >
                  <h4>{template.name}</h4>
                  <p>{template.description}</p>
                </div>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-primary"
          >
            {loading ? 'Creating...' : '✨ Create Website'}
          </button>
        </form>
      </div>

      <div className="websites-section">
        <h3>Your Websites ({websites.length})</h3>
        {websites.length === 0 ? (
          <p className="no-items">No websites created yet. Create one above!</p>
        ) : (
          <div className="websites-list">
            {websites.map((website) => (
              <div key={website.id} className="website-card">
                <div className="website-info">
                  <h4>{website.name}</h4>
                  <p>{website.description}</p>
                  <div className="website-meta">
                    <span className="badge">{website.template}</span>
                    <span className="date">
                      Created: {new Date(website.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <div className="website-actions">
                  <button className="btn-small">👁️ Preview</button>
                  <button className="btn-small">✏️ Edit</button>
                  <button className="btn-small">📦 Export</button>
                  <button className="btn-small danger">🗑️ Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default WebsiteBuilder;
