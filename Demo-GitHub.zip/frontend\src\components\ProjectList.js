import React from 'react';
import '../styles/ProjectList.css';

function ProjectList({ projects, databases, onRefresh }) {
  const websites = projects.filter(p => p.type === 'website');
  const games = projects.filter(p => p.type === 'game');
  const integratedProjects = projects.filter(p => p.linked_database);

  return (
    <div className="project-list">
      <h2>📊 Dashboard</h2>

      <div className="dashboard-stats">
        <div className="stat-card">
          <h3>{websites.length}</h3>
          <p>Websites</p>
        </div>
        <div className="stat-card">
          <h3>{games.length}</h3>
          <p>Games</p>
        </div>
        <div className="stat-card">
          <h3>{databases.length}</h3>
          <p>Databases</p>
        </div>
        <div className="stat-card">
          <h3>{integratedProjects.length}</h3>
          <p>Integrated</p>
        </div>
      </div>

      <button onClick={onRefresh} className="btn-secondary refresh-btn">
        🔄 Refresh Data
      </button>

      <div className="projects-overview">
        <div className="overview-section">
          <h3>🌐 Websites ({websites.length})</h3>
          {websites.length === 0 ? (
            <p className="no-items">No websites created yet</p>
          ) : (
            <div className="overview-list">
              {websites.map((website) => (
                <div key={website.id} className="overview-item">
                  <div className="item-header">
                    <h4>{website.name}</h4>
                    {website.linked_database && (
                      <span className="linked-badge">🔗 Linked</span>
                    )}
                  </div>
                  <p>{website.description}</p>
                  <div className="item-footer">
                    <span className="badge">{website.template}</span>
                    <span className="date">
                      {new Date(website.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="overview-section">
          <h3>🎮 Games ({games.length})</h3>
          {games.length === 0 ? (
            <p className="no-items">No games created yet</p>
          ) : (
            <div className="overview-list">
              {games.map((game) => (
                <div key={game.id} className="overview-item">
                  <div className="item-header">
                    <h4>{game.name}</h4>
                    {game.linked_database && (
                      <span className="linked-badge">🔗 Linked</span>
                    )}
                  </div>
                  <p>{game.description}</p>
                  <div className="item-footer">
                    <span className="badge">{game.game_type}</span>
                    <span className="badge">{game.framework}</span>
                    <span className="date">
                      {new Date(game.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="overview-section">
          <h3>🗄️ Databases ({databases.length})</h3>
          {databases.length === 0 ? (
            <p className="no-items">No databases connected yet</p>
          ) : (
            <div className="overview-list">
              {databases.map((database) => (
                <div key={database.id} className="overview-item">
                  <div className="item-header">
                    <h4>{database.database}</h4>
                  </div>
                  <p>Type: {database.type.toUpperCase()}</p>
                  <div className="item-footer">
                    <span className="badge">{database.type}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="quick-stats">
        <h3>📈 Quick Statistics</h3>
        <div className="stats-grid">
          <div className="stat-box">
            <p>Total Projects</p>
            <h3>{websites.length + games.length}</h3>
          </div>
          <div className="stat-box">
            <p>Integrated Projects</p>
            <h3>{integratedProjects.length}</h3>
          </div>
          <div className="stat-box">
            <p>Database Connections</p>
            <h3>{databases.length}</h3>
          </div>
          <div className="stat-box">
            <p>Integration Rate</p>
            <h3>
              {websites.length + games.length === 0
                ? '0'
                : Math.round(
                    (integratedProjects.length / (websites.length + games.length)) *
                      100
                  )}
              %
            </h3>
          </div>
        </div>
      </div>

      <div className="getting-started">
        <h3>🚀 Getting Started</h3>
        <div className="steps">
          <div className="step">
            <span className="step-number">1</span>
            <div className="step-content">
              <h4>Create a Website or Game</h4>
              <p>Use the Website Builder or Game Builder to create your project</p>
            </div>
          </div>
          <div className="step">
            <span className="step-number">2</span>
            <div className="step-content">
              <h4>Set Up Database</h4>
              <p>Connect to a database and create tables for your data</p>
            </div>
          </div>
          <div className="step">
            <span className="step-number">3</span>
            <div className="step-content">
              <h4>Link Components</h4>
              <p>Link your project to the database using the Integration tab</p>
            </div>
          </div>
          <div className="step">
            <span className="step-number">4</span>
            <div className="step-content">
              <h4>Deploy</h4>
              <p>Deploy your fully integrated project and start using it</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProjectList;
