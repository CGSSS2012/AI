import React, { useState, useEffect } from 'react';
import './App.css';
import DatabaseManager from './components/DatabaseManager';
import WebsiteBuilder from './components/WebsiteBuilder';
import GameBuilder from './components/GameBuilder';
import ProjectIntegration from './components/ProjectIntegration';
import ProjectList from './components/ProjectList';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [projects, setProjects] = useState([]);
  const [databases, setDatabases] = useState([]);
  const [loading, setLoading] = useState(false);

  const API_BASE = 'http://localhost:5000/api';

  // Fetch projects and databases on component mount
  useEffect(() => {
    fetchProjects();
    fetchDatabases();
  }, []);

  const fetchProjects = async () => {
    try {
      const response = await fetch(`${API_BASE}/projects`);
      const data = await response.json();
      if (data.success) {
        setProjects(data.projects);
      }
    } catch (error) {
      console.error('Error fetching projects:', error);
    }
  };

  const fetchDatabases = async () => {
    try {
      const response = await fetch(`${API_BASE}/databases`);
      const data = await response.json();
      if (data.success) {
        setDatabases(data.databases);
      }
    } catch (error) {
      console.error('Error fetching databases:', error);
    }
  };

  const handleRefresh = () => {
    fetchProjects();
    fetchDatabases();
  };

  return (
    <div className="App">
      <header className="app-header">
        <h1>🚀 Multi-Purpose Development Agent</h1>
        <p>Create websites, games, manage databases, and link them all together</p>
      </header>

      <nav className="app-nav">
        <button
          className={`nav-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
          onClick={() => setActiveTab('dashboard')}
        >
          📊 Dashboard
        </button>
        <button
          className={`nav-btn ${activeTab === 'databases' ? 'active' : ''}`}
          onClick={() => setActiveTab('databases')}
        >
          🗄️ Databases
        </button>
        <button
          className={`nav-btn ${activeTab === 'websites' ? 'active' : ''}`}
          onClick={() => setActiveTab('websites')}
        >
          🌐 Websites
        </button>
        <button
          className={`nav-btn ${activeTab === 'games' ? 'active' : ''}`}
          onClick={() => setActiveTab('games')}
        >
          🎮 Games
        </button>
        <button
          className={`nav-btn ${activeTab === 'integration' ? 'active' : ''}`}
          onClick={() => setActiveTab('integration')}
        >
          🔗 Integration
        </button>
      </nav>

      <main className="app-content">
        {activeTab === 'dashboard' && (
          <ProjectList
            projects={projects}
            databases={databases}
            onRefresh={handleRefresh}
          />
        )}

        {activeTab === 'databases' && (
          <DatabaseManager
            databases={databases}
            onDatabasesChange={fetchDatabases}
          />
        )}

        {activeTab === 'websites' && (
          <WebsiteBuilder
            onProjectCreated={fetchProjects}
          />
        )}

        {activeTab === 'games' && (
          <GameBuilder
            onProjectCreated={fetchProjects}
          />
        )}

        {activeTab === 'integration' && (
          <ProjectIntegration
            projects={projects}
            databases={databases}
            onIntegrationComplete={fetchProjects}
          />
        )}
      </main>

      <footer className="app-footer">
        <p>Multi-Purpose Development Agent v1.0 | Powered by Python + React</p>
      </footer>
    </div>
  );
}

export default App;
