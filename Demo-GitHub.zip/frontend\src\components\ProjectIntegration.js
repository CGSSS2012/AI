import React, { useState, useEffect } from 'react';
import '../styles/ProjectIntegration.css';

function ProjectIntegration({ projects, databases, onIntegrationComplete }) {
  const [selectedProject, setSelectedProject] = useState('');
  const [selectedDatabase, setSelectedDatabase] = useState('');
  const [endpoints, setEndpoints] = useState({
    api_base: '/api',
    get_endpoint: '/api/data',
    post_endpoint: '/api/data'
  });
  const [integrations, setIntegrations] = useState([]);
  const [loading, setLoading] = useState(false);

  const API_BASE = 'http://localhost:5000/api';

  useEffect(() => {
    loadIntegrations();
  }, []);

  const loadIntegrations = async () => {
    const projectsWithDb = projects.filter(p => p.linked_database);
    setIntegrations(projectsWithDb);
  };

  const linkComponents = async () => {
    if (!selectedProject || !selectedDatabase) {
      alert('Please select both a project and a database');
      return;
    }

    setLoading(true);
    try {
      const project = projects.find(p => p.id === selectedProject);
      const projectType = project?.type || 'unknown';

      const response = await fetch(`${API_BASE}/projects/link`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          project_id: selectedProject,
          project_type: projectType,
          database_id: selectedDatabase,
          endpoints: endpoints
        })
      });

      const data = await response.json();
      if (data.success) {
        alert('Integration successful!');
        setSelectedProject('');
        setSelectedDatabase('');
        onIntegrationComplete();
        loadIntegrations();
      } else {
        alert('Error: ' + data.error);
      }
    } catch (error) {
      alert('Error linking components: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const deployProject = async (projectId) => {
    try {
      const response = await fetch(`${API_BASE}/projects/${projectId}/deploy`, {
        method: 'POST'
      });

      const data = await response.json();
      if (data.success) {
        alert(`Project deployed to: ${data.location}`);
      } else {
        alert('Error: ' + data.error);
      }
    } catch (error) {
      alert('Error deploying project: ' + error.message);
    }
  };

  const nonIntegratedProjects = projects.filter(p => !p.linked_database);

  return (
    <div className="project-integration">
      <h2>🔗 Project Integration</h2>

      <div className="integration-section">
        <h3>Link Project to Database</h3>

        {nonIntegratedProjects.length === 0 ? (
          <p className="no-items">All projects are integrated or no projects exist</p>
        ) : (
          <div className="integration-form">
            <div className="form-group">
              <label>Select Project</label>
              <select
                value={selectedProject}
                onChange={(e) => setSelectedProject(e.target.value)}
              >
                <option value="">-- Choose a project --</option>
                {nonIntegratedProjects.map((project) => (
                  <option key={project.id} value={project.id}>
                    {project.name} ({project.type})
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>Select Database</label>
              <select
                value={selectedDatabase}
                onChange={(e) => setSelectedDatabase(e.target.value)}
              >
                <option value="">-- Choose a database --</option>
                {databases.map((db) => (
                  <option key={db.id} value={db.id}>
                    {db.database} ({db.type})
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label>API Base URL</label>
              <input
                type="text"
                value={endpoints.api_base}
                onChange={(e) => setEndpoints({...endpoints, api_base: e.target.value})}
                placeholder="/api"
              />
            </div>

            <button
              onClick={linkComponents}
              disabled={loading || !selectedProject || !selectedDatabase}
              className="btn-primary"
            >
              {loading ? 'Linking...' : '🔗 Link Components'}
            </button>
          </div>
        )}
      </div>

      <div className="integrations-section">
        <h3>Active Integrations ({integrations.length})</h3>

        {integrations.length === 0 ? (
          <p className="no-items">No active integrations yet</p>
        ) : (
          <div className="integrations-list">
            {integrations.map((project) => {
              const db = databases.find(d => d.id === project.linked_database);
              return (
                <div key={project.id} className="integration-card">
                  <div className="integration-info">
                    <div className="project-info">
                      <h4>{project.name}</h4>
                      <p className="type-badge">{project.type}</p>
                    </div>
                    <div className="arrow">→</div>
                    <div className="database-info">
                      <h4>{db?.database}</h4>
                      <p className="type-badge">{db?.type}</p>
                    </div>
                  </div>

                  <div className="integration-details">
                    <p>Database ID: <code>{project.linked_database}</code></p>
                    <p>Created: {new Date(project.created_at).toLocaleDateString()}</p>
                  </div>

                  <div className="integration-actions">
                    <button
                      onClick={() => deployProject(project.id)}
                      className="btn-primary"
                    >
                      📦 Deploy
                    </button>
                    <button className="btn-small">👁️ View Code</button>
                    <button className="btn-small">⚙️ Configure</button>
                    <button className="btn-small danger">🔗 Unlink</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="info-section">
        <h3>📚 How Integration Works</h3>
        <div className="info-box">
          <ol>
            <li>Create a website or game using the builders</li>
            <li>Set up a database and create tables</li>
            <li>Link the project to the database</li>
            <li>Use the generated API helpers to connect to your database</li>
            <li>Deploy your fully integrated project</li>
          </ol>
          <h4>Supported Features:</h4>
          <ul>
            <li>✅ Automatic API code generation</li>
            <li>✅ Database connection helpers</li>
            <li>✅ CRUD operations (Create, Read, Update, Delete)</li>
            <li>✅ Multiple database support (MySQL, PostgreSQL, SQLite)</li>
            <li>✅ Game highscore tracking</li>
            <li>✅ Website data management</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default ProjectIntegration;
