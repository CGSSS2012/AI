import React, { useState } from 'react';
import '../styles/DatabaseManager.css';

function DatabaseManager({ databases, onDatabasesChange }) {
  const [showForm, setShowForm] = useState(false);
  const [dbType, setDbType] = useState('sqlite');
  const [formData, setFormData] = useState({
    host: 'localhost',
    port: 3306,
    username: '',
    password: '',
    database: '',
    file_path: './database.db'
  });
  const [selectedDb, setSelectedDb] = useState(null);
  const [tables, setTables] = useState([]);
  const [showTableForm, setShowTableForm] = useState(false);
  const [tableName, setTableName] = useState('');
  const [columns, setColumns] = useState([{ name: '', type: 'VARCHAR(255)', primary_key: false }]);

  const API_BASE = 'http://localhost:5000/api';

  const handleConnect = async () => {
    try {
      const payload = {
        db_type: dbType,
        ...formData
      };

      const response = await fetch(`${API_BASE}/databases/connect`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      if (data.success) {
        alert('Database connected successfully!');
        setShowForm(false);
        onDatabasesChange();
      } else {
        alert('Error: ' + data.error);
      }
    } catch (error) {
      alert('Error connecting to database: ' + error.message);
    }
  };

  const loadTables = async (dbId) => {
    try {
      const response = await fetch(`${API_BASE}/databases/${dbId}/tables`);
      const data = await response.json();
      if (data.success) {
        setTables(data.tables);
        setSelectedDb(dbId);
      }
    } catch (error) {
      alert('Error loading tables: ' + error.message);
    }
  };

  const createTable = async () => {
    if (!tableName.trim()) {
      alert('Please enter a table name');
      return;
    }

    if (columns.some(col => !col.name.trim())) {
      alert('Please fill in all column names');
      return;
    }

    try {
      const response = await fetch(`${API_BASE}/databases/${selectedDb}/tables/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: tableName,
          columns: columns
        })
      });

      const data = await response.json();
      if (data.success) {
        alert('Table created successfully!');
        setTableName('');
        setColumns([{ name: '', type: 'VARCHAR(255)', primary_key: false }]);
        setShowTableForm(false);
        loadTables(selectedDb);
      } else {
        alert('Error: ' + data.error);
      }
    } catch (error) {
      alert('Error creating table: ' + error.message);
    }
  };

  const addColumn = () => {
    setColumns([...columns, { name: '', type: 'VARCHAR(255)', primary_key: false }]);
  };

  const removeColumn = (index) => {
    if (columns.length > 1) {
      setColumns(columns.filter((_, i) => i !== index));
    }
  };

  const updateColumn = (index, field, value) => {
    const newColumns = [...columns];
    newColumns[index][field] = value;
    setColumns(newColumns);
  };

  return (
    <div className="database-manager">
      <h2>🗄️ Database Manager</h2>

      <div className="db-section">
        <h3>Connected Databases</h3>
        {databases.length === 0 ? (
          <p className="no-items">No databases connected yet</p>
        ) : (
          <div className="databases-list">
            {databases.map((db) => (
              <div key={db.id} className="database-card">
                <div className="db-info">
                  <strong>{db.type.toUpperCase()}</strong>
                  <p>{db.database}</p>
                </div>
                <button onClick={() => loadTables(db.id)} className="btn-primary">
                  View Tables
                </button>
              </div>
            ))}
          </div>
        )}

        <button
          onClick={() => setShowForm(!showForm)}
          className="btn-secondary"
        >
          {showForm ? 'Cancel' : '➕ New Connection'}
        </button>
      </div>

      {showForm && (
        <div className="form-section">
          <h3>Connect Database</h3>

          <div className="form-group">
            <label>Database Type</label>
            <select value={dbType} onChange={(e) => setDbType(e.target.value)}>
              <option value="sqlite">SQLite</option>
              <option value="mysql">MySQL</option>
              <option value="postgresql">PostgreSQL</option>
            </select>
          </div>

          {dbType === 'sqlite' ? (
            <div className="form-group">
              <label>Database File Path</label>
              <input
                type="text"
                value={formData.file_path}
                onChange={(e) => setFormData({...formData, file_path: e.target.value})}
                placeholder="./database.db"
              />
            </div>
          ) : (
            <>
              <div className="form-group">
                <label>Host</label>
                <input
                  type="text"
                  value={formData.host}
                  onChange={(e) => setFormData({...formData, host: e.target.value})}
                  placeholder="localhost"
                />
              </div>

              <div className="form-group">
                <label>Port</label>
                <input
                  type="number"
                  value={formData.port}
                  onChange={(e) => setFormData({...formData, port: parseInt(e.target.value)})}
                />
              </div>

              <div className="form-group">
                <label>Username</label>
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => setFormData({...formData, username: e.target.value})}
                />
              </div>

              <div className="form-group">
                <label>Password</label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                />
              </div>

              <div className="form-group">
                <label>Database Name</label>
                <input
                  type="text"
                  value={formData.database}
                  onChange={(e) => setFormData({...formData, database: e.target.value})}
                />
              </div>
            </>
          )}

          <button onClick={handleConnect} className="btn-primary">
            Connect Database
          </button>
        </div>
      )}

      {selectedDb && (
        <div className="tables-section">
          <h3>Tables in Database</h3>
          {tables.length === 0 ? (
            <p className="no-items">No tables in this database</p>
          ) : (
            <div className="tables-list">
              {tables.map((table) => (
                <div key={table} className="table-item">
                  <span>{table}</span>
                  <div className="table-actions">
                    <button className="btn-small">📊 View</button>
                    <button className="btn-small">✏️ Edit</button>
                    <button className="btn-small danger">🗑️ Delete</button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <button
            onClick={() => setShowTableForm(!showTableForm)}
            className="btn-secondary"
          >
            {showTableForm ? 'Cancel' : '➕ Create Table'}
          </button>
        </div>
      )}

      {showTableForm && selectedDb && (
        <div className="form-section">
          <h3>Create New Table</h3>

          <div className="form-group">
            <label>Table Name</label>
            <input
              type="text"
              value={tableName}
              onChange={(e) => setTableName(e.target.value)}
              placeholder="users"
            />
          </div>

          <div className="columns-editor">
            <h4>Columns</h4>
            {columns.map((column, index) => (
              <div key={index} className="column-input-group">
                <input
                  type="text"
                  placeholder="Column name"
                  value={column.name}
                  onChange={(e) => updateColumn(index, 'name', e.target.value)}
                />
                <select
                  value={column.type}
                  onChange={(e) => updateColumn(index, 'type', e.target.value)}
                >
                  <option>VARCHAR(255)</option>
                  <option>INTEGER</option>
                  <option>FLOAT</option>
                  <option>BOOLEAN</option>
                  <option>DATETIME</option>
                  <option>TEXT</option>
                </select>
                <label>
                  <input
                    type="checkbox"
                    checked={column.primary_key}
                    onChange={(e) => updateColumn(index, 'primary_key', e.target.checked)}
                  />
                  Primary Key
                </label>
                {columns.length > 1 && (
                  <button
                    onClick={() => removeColumn(index)}
                    className="btn-small danger"
                  >
                    ✕
                  </button>
                )}
              </div>
            ))}
            <button onClick={addColumn} className="btn-secondary">
              ➕ Add Column
            </button>
          </div>

          <button onClick={createTable} className="btn-primary">
            Create Table
          </button>
        </div>
      )}
    </div>
  );
}

export default DatabaseManager;
